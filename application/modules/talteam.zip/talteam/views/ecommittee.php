<div class="container">
					<div class="row pt-5">

						<div class="col-lg-12">

							<h1 class="mb-0">Executive Committee</h1>
							<div class="divider divider-primary divider-small mb-4">
								<hr class="mr-auto">
							</div>

							<div class="row team-list mt-1 sort-destinationn">
								
							
								
								
									
								<?php
                                foreach($query->result() as $row){
									
									if($row->team_img==''){
											$team_photo = "no_img.jpg";
										} else {
											$team_photo = $row->team_img;
										}
								
								?>	
								<div class="col-md-6 col-lg-4 mb-5 text-center isotope-item criminal-law new-york">
										<span class="thumb-info thumb-info-centered-info thumb-info-no-borders">
											<span class="thumb-info-wrapper">
												<img src="<?= base_url() ?>assets/images/teams/<?= $team_photo ?>" class="img-fluid" alt="">
											</span>
										</span>
									<h4 class="mt-3 mb-0"><?= $row->team_name ?></h4>
									<p class="mb-0"><?= $row->team_desc ?></p>
								</div>
                                <?php } ?>
									
								
							
								
                                
                                
                            
                            
                            
                            		
						
							</div>
						

						</div>

					</div>

				</div>