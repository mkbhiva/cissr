<h1><?= $headline ?></h1>
<?php echo validation_errors("<p style='color:red;'>","</p>"); ?>
<?php if(isset($flash)){
	echo $flash;
}else{
	echo '<p>&nbsp;</p>';
}?>

<?php if(is_numeric($update_id)){ ?>
<div class="row-fluid sortablee">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon white edit"></i><span class="break"></span>Team Member Options</h2>
        </div>
        
        <div class="box-content">
        <?php if($team_img=="") { ?>
               <a href="<?= base_url() ?>teams/upload_image/<?= $update_id ?>"><button type="button" class="btn btn-primary">Upload Image</button></a>
               <?php } else { ?>
               <a href="<?= base_url() ?>teams/delete_image/<?= $update_id ?>"><button type="button" class="btn btn-danger">Delete Image</button></a>
               <?php } ?>
        </div>
    </div><!--/span-->
</div>
<?php } ?>

<div class="row-fluid sortablee">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon white edit"></i><span class="break"></span>Team Member Details</h2>
        </div>
        
        <div class="box-content">
        <?php
        $form_location = base_url()."teams/create/".$update_id;
		
		?>
            <form class="form-horizontal" action="<?php echo $form_location ;?>" method="post" enctype="multipart/form-data">
                <fieldset>
                    <div class="control-group">
                        <label class="control-label" for="typeahead">Team Member Name </label>
                        <div class="controls">
                            <input type="text" name="team_name" class="span6 typeahead" value="<?= $team_name ?>" id="typeahead">
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label" for="selectError">Team Member Type</label>
                        <div class="controls">
                        <?php
                        $additional_dd_code = 'id="selectError"';

                                
                            echo form_dropdown('team_type', $options, $team_type, $additional_dd_code);
                                                                
                        ?>
                        </div>
                      </div>
                      
                      
                      <div class="control-group">
                        <label class="control-label" for="typeahead">Priority </label>
                        <div class="controls">
                            <input type="text" name="team_priority" class="span6 typeahead" value="<?= $team_priority ?>" id="typeahead">
                        </div>
                    </div>
                    
                    
                

                    <div class="control-group hidden-phonee">
                        <label class="control-label" for="textarea2">Description</label>
                        <div class="controls">
                            <textarea class="cleditor" name="team_desc" id="textarea2" rows="3"><?= $team_desc ?></textarea>
                        </div>
                    </div>
                    
                    
                    <div class="control-group">
								<label class="control-label" for="selectError">Status</label>
								<div class="controls">
                                <?php
								$additional_dd_code = 'id="selectError"';
                                $options = array(
												'1'         => 'Active',
												'0'           => 'Inactive',
										);
										
										echo form_dropdown('team_status', $options, $team_status, $additional_dd_code);
																		
								?>
								</div>
							  </div>
 
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary" name="submit" value="Submit">Save changes</button>
                        <a href="<?= base_url() ?>teams/manage" class="btn">Cancel</a>
                    </div>
                </fieldset>
            </form>   

        </div>
    </div><!--/span-->

</div>

<?php if($team_img!="") { ?>
<div class="row-fluid sortablee">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon white edit"></i><span class="break"></span>Team Member Image</h2>
        </div>
        
        <div class="box-content">
               <img src="<?= base_url() ?>assets/images/teams/main/<?= $team_img ?>" width="200" />
        </div>
    </div><!--/span-->
</div>
<?php } ?>